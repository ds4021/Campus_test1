﻿using Microsoft.AspNetCore.WebUtilities;

namespace WebApplication2.Controllers
{
    public interface IBufferedFileUploadService
    {
        Task<bool> UploadFile(IFormFile file);
    }
}
