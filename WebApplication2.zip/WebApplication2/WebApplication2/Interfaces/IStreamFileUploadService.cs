﻿using Microsoft.AspNetCore.WebUtilities;

namespace WebApplication2.Controllers
{
    public interface IStreamFileUploadService
    {
        Task<bool> UploadFile(MultipartReader reader, MultipartSection section);
    }
}
